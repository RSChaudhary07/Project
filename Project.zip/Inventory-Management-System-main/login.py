from tkinter import *
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import sqlite3
import os
class LoginClass:
    def __init__(self, root):
        self.root = root
        self.root.title("Login Page")
        self.root.geometry("1350x700+0+0")
        self.root.config(bg="#fafafa")

        # =====images========
        self.phone_image = ImageTk.PhotoImage(
            file="images/photo.jpg")
        self.lbl_phone_image = Label(
            self.root, image=self.phone_image, bd=0).place(x=200, y=60)

        # ==============frame============
        f1_frame = Frame(self.root, bd=0, relief=RIDGE, bg="white")
        f1_frame.place(x=650, y=90, width=350, height=60)
        title1 = Label(f1_frame, text="JAI HIND", fg="#ffa500", font=(
            "Elephant", 25, "bold"), bg="white").place(x=0, y=5, relwidth=1)

        # ========login_frame===========
        login_frame = Frame(self.root, bd=0, relief=RIDGE, bg="white")
        login_frame.place(x=650, y=155, width=350, height=500)

        self.employee = StringVar()
        self.pwd = StringVar()
        title = Label(login_frame, text="Login System", font=(
            "Elephant", 30, "bold"), bg="white").place(x=0, y=10, relwidth=1)

        lbl_employee = Label(login_frame, text="Employee ID", font=(
            "Andalus", 15), bg="white", fg="#555555").place(x=50, y=120)
        txt_emp_id = Entry(login_frame, textvariable=self.employee, font=(
            "times new roman", 15), bg="#ECECEC").place(x=50, y=160, width=250)

        lbl_pwd = Label(login_frame, text="Password", font=(
            "Andalus", 15), bg="white", fg="#767171").place(x=50, y=210)
        txt_pwd = Entry(login_frame, textvariable=self.pwd, show="*",
                        font=("times new roman", 15), bg="#ECECEC").place(x=50, y=260, width=250)

        btn_login = Button(login_frame, command=self.login, text="Log In", font=("Arial Rounded MT Bold", 15), bg="#00B0F0",
                           activebackground="#00B0F0", fg="white", activeforeground="white", cursor="hand2").place(x=50, y=320, width=250, height=35)

        hr = Label(login_frame, bg="lightgray").place(
            x=50, y=390, width=250, height=2)
        or_ = Label(login_frame, text="OR", bg="lightgray", font=(
            "times new roman", 15, "bold")).place(x=150, y=375)

        btn_forget = Button(login_frame, text="Forget Password?", font=("times new roman", 13),
                            bg="white", fg="#00759E", bd=0, activebackground="white", activeforeground="#00759E").place(x=100, y=430)

    def login(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
            if self.employee.get() == "" or self.pwd.get() == "":
                messagebox.showerror(
                    "Error", "Please enter all fields", parent=self.root)
            cur.execute("select utype from employee where eid=? and pass=?",
                        (self.employee.get(), self.pwd.get()))
            user = cur.fetchone()
            if user is None:
                messagebox.showerror(
                    "Error", "Invalid Employee ID or Password", parent=self.root)
            else:
                if user[0] == "Admin":
                    self.root.destroy()
                    os.system("python dashboard.py")

                else:
                    self.root.destroy()
                    os.system("python billing.py")

        except Exception as ex:
            messagebox.showerror(
                "Error", f"Error due to : {str(ex)}", parent=self.root)
            

if __name__=="__main__":
    root = Tk()
    obj = LoginClass(root)
    root.mainloop()